import type { HTMLAttributes } from "react";

import { cn } from "../../lib/cn";

export function Card({
    className,
    ...props
}: HTMLAttributes<HTMLDivElement>) {
    return (
        <div
            className={cn(
                "rounded-[var(--radius-card)]",
                "border border-[var(--color-border)]",
                "bg-[var(--color-surface)]",
                "shadow-[var(--shadow-xs)]",
                className,
            )}
            {...props}
        />
    );
}

export function CardHeader({
    className,
    ...props
}: HTMLAttributes<HTMLDivElement>) {
    return (
        <div
            className={cn("px-5 pt-5", className)}
            {...props}
        />
    );
}

export function CardContent({
    className,
    ...props
}: HTMLAttributes<HTMLDivElement>) {
    return (
        <div
            className={cn("p-5", className)}
            {...props}
        />
    );
}

export function CardFooter({
    className,
    ...props
}: HTMLAttributes<HTMLDivElement>) {
    return (
        <div
            className={cn(
                "flex items-center px-5 pb-5",
                className,
            )}
            {...props}
        />
    );
}